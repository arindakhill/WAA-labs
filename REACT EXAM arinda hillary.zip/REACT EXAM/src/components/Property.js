import React from 'react'

const Property = ({type, price})=>{

    return(
        <div className="property">
            <p>Type:{type}</p>
            <p>Price:{price}</p>
        </div>
    )

};
export default Property