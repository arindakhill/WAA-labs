// src/components/Properties.js

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import Property from './Property';

const Properties = () => {
  const { communityId } = useParams();
  const navigate = useNavigate();
  const [properties, setProperties] = useState([]);
  const [communityName, setCommunityName] = useState('');

  useEffect(() => {
    axios.get(`https://65bd8dd8b51f9b29e9338ba8.mockapi.io/api/v1/communities/${communityId}`)
      .then(response => {
        setCommunityName(response.data.name);
        setProperties(response.data.properties || []);
      })
      .catch(error => console.error("Fetch error:", error));
  }, [communityId]);

  return (
    <div>
      <h1>{communityName}</h1>
      {properties.map(property => (
        <Property key={property.id} {...property} />
      ))}
      <Link to={`/communities/${communityId}/add-property`}>Add Property</Link>
      <button onClick={() => navigate(-1)}>Back</button>
    </div>
  );
};

export default Properties;
