INSERT INTO users (name) VALUES ('User 1'), ('User 2'), ('User 3');

INSERT INTO post (title, content, author, user_id) VALUES
                                                        ('Title 1', 'Content for post 1', 'Author 1', 1),
                                                        ('Title 2', 'Content for post 2', 'Author 1', 1),
                                                        ('Title 3', 'Content for post 3', 'Author 1', 1),
                                                        ('Title 4', 'Content for post 4', 'Author 1', 1),
                                                        ('Title 5', 'Content for post 5', 'Author 1', 1),
                                                        ('Title 6', 'Content for post 6', 'Author 2', 2),
                                                        ('Title 7', 'Content for post 7', 'Author 2', 2),
                                                        ('Title 8', 'Content for post 8', 'Author 2', 2),
                                                        ('Title 9', 'Content for post 9', 'Author 2', 2),
                                                        ('Title 10', 'Content for post 10', 'Author 2', 2),
                                                        ('Title 11', 'Content for post 11', 'Author 3', 3),
                                                        ('Title 12', 'Content for post 12', 'Author 3', 3),
                                                        ('Title 13', 'Content for post 13', 'Author 3', 3),
                                                        ('Title 14', 'Content for post 14', 'Author 3', 3),
                                                        ('Title 15', 'Content for post 15', 'Author 3', 3);
