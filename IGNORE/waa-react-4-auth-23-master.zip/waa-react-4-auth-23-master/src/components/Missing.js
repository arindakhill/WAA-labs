import React from "react";


const Missing = () => {

    return <div>
        <h1> Sorry page not found... 404 </h1>
    </div>

}

export default Missing;