import React from 'react';

export const SelectedBooks = React.createContext([]);